#!/usr/bin/env python3
"""Scores a predictions CSV against a gold CSV (same schema as sample_output.csv).

Metrics:
  status_acc      : share of cases whose deletion_status matches gold
  step_precision  : matched steps / predicted steps (multiset of
                    phase, operation, system_id, resource_id, state, evidence_id)
  step_recall     : matched steps / gold steps
  field_acc       : per-field agreement over position-aligned steps
  seq_exact       : share of cases whose full ordered step list matches exactly
  json_ok         : share of steps_json values that parse as JSON arrays

Usage:
    python3 code/evaluation/main.py --pred output.csv --gold dataset/sample_output.csv
"""
import argparse
import csv
import json
from collections import Counter

FIELDS = ["phase", "system_id", "resource_id", "operation", "state", "evidence_id"]


def load(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return {r["case_id"]: r for r in csv.DictReader(fh)}


def parse_steps(text):
    try:
        v = json.loads(text)
        return v if isinstance(v, list) else None
    except (json.JSONDecodeError, TypeError):
        return None


def step_key(s):
    return tuple(s.get(f, "") for f in FIELDS)


def score(pred, gold):
    cases = sorted(gold)
    status_ok = seq_ok = json_ok = 0
    matched = pred_total = gold_total = 0
    field_ok = field_total = 0
    failures = []
    for cid in cases:
        g = gold[cid]
        p = pred.get(cid)
        if p is None:
            failures.append((cid, "missing prediction"))
            continue
        if p["deletion_status"] == g["deletion_status"]:
            status_ok += 1
        else:
            failures.append((cid, f"status pred={p['deletion_status']} gold={g['deletion_status']}"))
        ps, gs = parse_steps(p["steps_json"]), parse_steps(g["steps_json"])
        if ps is not None:
            json_ok += 1
        ps, gs = ps or [], gs or []
        pc, gc = Counter(step_key(s) for s in ps), Counter(step_key(s) for s in gs)
        matched += sum((pc & gc).values())
        pred_total += len(ps)
        gold_total += len(gs)
        for a, b in zip(ps, gs):
            for f in FIELDS:
                field_total += 1
                field_ok += int(a.get(f, "") == b.get(f, ""))
        if [step_key(s) for s in ps] == [step_key(s) for s in gs]:
            seq_ok += 1
    n = len(cases)
    return {
        "cases": n,
        "status_acc": status_ok / n,
        "step_precision": matched / pred_total if pred_total else 1.0,
        "step_recall": matched / gold_total if gold_total else 1.0,
        "field_acc": field_ok / field_total if field_total else 1.0,
        "seq_exact": seq_ok / n,
        "json_ok": json_ok / n,
        "failures": failures,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True)
    ap.add_argument("--gold", required=True)
    args = ap.parse_args()
    m = score(load(args.pred), load(args.gold))
    for k in ("cases", "status_acc", "step_precision", "step_recall", "field_acc", "seq_exact", "json_ok"):
        v = m[k]
        print(f"{k:16s} {v:.4f}" if isinstance(v, float) else f"{k:16s} {v}")
    print(f"failing cases    {len(m['failures'])}")
    for cid, msg in m["failures"][:40]:
        print(f"  {cid}: {msg}")


if __name__ == "__main__":
    main()
