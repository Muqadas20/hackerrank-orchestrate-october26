# Evaluation Report - Ghost Data Still Exists

This report covers the final deterministic pipeline in `code/main.py`. All figures below come from runs of
`code/evaluation/main.py` and `code/evaluation/custom_cases.py` on this repository. Nothing here is estimated.

## 1. Important caveat: which numbers are trustworthy

The hidden canonical answers for the 518 evaluation requests are not available. The only labelled data is the 32
sample requests in `dataset/sample_output.csv`. Those 32 answers were used while developing the rules: I inspected
the sample cases, the evidence they cite, and the gap between my output and the sample answers, then changed the
rules. The sample scores below are therefore **development-set scores and are optimistic**. They show that the
rules reproduce the sample answers; they do not estimate accuracy on the hidden set.

The rule vocabulary (record types, states, operations, evidence-citation behaviour) was taken from data across the
full 518-request evidence set, not from the sample answers alone, but the final tuning used the sample answers.

## 2. Sample-set metrics (development set, 32 cases)

Command:

```text
python3 code/main.py --requests dataset/sample_deletion_requests.csv --out /tmp/sample_pred.csv
python3 code/evaluation/main.py --pred /tmp/sample_pred.csv --gold dataset/sample_output.csv
```

| Metric | Final value | Meaning |
| --- | --- | --- |
| Case-level status accuracy | 90.62% (29/32) | `deletion_status` matches gold |
| Step precision | 97.62% | predicted steps that match a gold step (operation, system, resource, phase, state, evidence) |
| Step recall | 84.97% | gold steps that the prediction reproduces |
| Field-level accuracy | 82.22% | per-field agreement on position-aligned steps (phase, system_id, resource_id, operation, state, evidence_id) |
| Exact sequence accuracy | 28.12% (9/32) | cases whose full ordered step list matches exactly |
| `steps_json` parse rate | 100% | every value parses as a JSON array |

Failing cases (all three are the same cause, described in section 5):

- `case_01`, `case_02`, `case_04`: gold COMPLETE; prediction INCOMPLETE. The gold answer proves the account is
  absent by citing evidence_54 for `account_001`, `account_002`, `account_004`. Those accounts have no link to the
  requester in the evidence, so the pipeline cannot prove their absence and does not claim COMPLETE.

## 3. Full-dataset run (518 requests, no gold labels)

Command: `python3 code/main.py` (writes `output.csv` at the repository root). Runtime: about 21 seconds on the
execution environment. Output file checks:

| Check | Result |
| --- | --- |
| Header is exactly `case_id,deletion_status,steps_json` | pass |
| Data rows | 518 (one per request, no duplicates, sorted by case_id) |
| Status values | COMPLETE 144, INCOMPLETE 370, NOT_APPLICABLE 4 |
| `steps_json` valid JSON | 518/518 |
| `step_no` consecutive from 1 | 518/518 |
| Phase order FINDING, REMEDIATION, VERIFICATION | 518/518 |
| Operation/state pairs match the allowed table | all steps |
| NOT_APPLICABLE rows have `[]` | 4/4 |
| Evidence ids exist in `evidence_files.csv` | all cited ids |
| INCOMPLETE remediation and verification steps have empty evidence_id | all |
| COMPLETE steps are verification steps with evidence | all |

These are structural checks. They do not show that the content is correct.

Known gaps in the full-run output:

- **42 INCOMPLETE cases have an empty `steps_json`.** These are requests whose subject's identity appears only in a
  document (a customer statement PDF) and not in any resource-level record, so the pipeline finds no resource to
  report or verify. COMPLETE cannot be proven, so these are reported INCOMPLETE with no steps. A full remediation
  plan needs resource identifiers that the evidence does not supply through the links implemented here. The
  canonical answers for these cases are unknown.
- **Account resources that are never linked.** Several subjects have an account whose absence would normally be
  verified, but no observation or reference links that account to the subject. These are omitted (see section 5).

## 4. Team-created evaluation cases (custom, all executed)

Command: `python3 code/evaluation/custom_cases.py`. Result: **5 of 5 passed**.

| Case | What it tests | Result |
| --- | --- | --- |
| C1 historical-email identity | A request submitted with a historical (pre-change) email must resolve to the same user and get the same answer | PASS. 2 cases had a historical email in the audit log; both gave identical status and steps. This is a narrow test: only two sample users have an email history. |
| C2 no evidence after audit cutoff | With `audit_at` set to 2020-01-01 (before all evidence), no evidence may be cited and no COMPLETE may be claimed | PASS. 0 cited evidence steps, 0 COMPLETE claims across 32 cases. |
| C3 non-deletion requests | Requests for a copy of data, or to change an email, must be NOT_APPLICABLE with `[]` | PASS. 3 of 3 became NOT_APPLICABLE. |
| C4 output contract | Structural contract over every row of the full `output.csv` (ordering, numbering, op/state, phase, evidence rules) | PASS. 518 rows, 0 violations. |
| C5 determinism | Two independent runs produce byte-identical output | PASS. |

Each case runs the real pipeline. None of them depends on the hidden answers.

## 5. Failures found and improvements made

Each row is a development iteration. Scores are the sample-set metrics measured after that change.

| Iteration | Change | Status | Step precision | Step recall | Sequence exact |
| --- | --- | --- | --- | --- | --- |
| 1 | First pass: email/hash identity, resource-prefix systems, generic record parsing | 71.9% | 61.7% | 40.9% | 3.1% |
| 2 | Classifier driven by record type and state (evidence vocabulary such as FOUND, IDENTIFIABLE, ACTIVE, BLOCKED); SQL `record_json` expanded | 81.3% | 65.8% | 50.8% | 3.1% |
| 3 | Subject linking through account references inside linked records; identifiers only from structured fields (not free text) | 87.5% | 61.2% | 44.0% | 6.3% |
| 4 | Identifiability from direct identifiers or contacts in text (not bare user-id references) | 90.6% | 65.8% | 50.8% | 6.3% |
| 5 | Log lines linked by trace_id; `*_started` request lines ignored as state | 93.8% | 66.9% | 54.4% | 6.3% |
| 6 | 64-hex values treated as hash identifiers (fixes a missed link via `correlation_key`); fixed a duplicate map key | 100% | 67.9% | 59.1% | 6.3% |
| 7 | Evidence citation = earliest observation at or before audit_at that already shows the final state (reproduces 71/71 gold citations) | 100% | 85.1% | 74.1% | 6.3% |
| 8 | COMPLETE requires at least one cited verification step, otherwise INCOMPLETE; INCOMPLETE remediation and verification cite no evidence | 90.6% | 97.6% | 85.0% | 28.1% |

Failures and their status:

- **Iteration 1 to 6, identity and linkage:** the first versions missed subjects whose records are linked only through
  a historical email, a trace-linked log line, a hash in a log field, or an account reference. Each was fixed by reading
  the raw evidence line that carried the link.
- **Iteration 6, status 100% on the development set, then 90.6%:** the 100% figure is what the rules gave before the
  proof rule. Iteration 8 deliberately lowered sample status accuracy to 90.6%. Before iteration 8 the three sample
  COMPLETE cases (`case_01`, `case_02`, `case_04`) were reported COMPLETE with no proof, and the empty-steps list was
  wrong for that reason. I kept the proof rule because the spec allows COMPLETE only when it can be shown. Those three
  cases remain wrong; they need an account link the evidence does not provide.
- **Unfixed: account resources without a link.** Gold verifies `account_001`, `account_002`, `account_004`, and
  similar accounts, but neither the evidence nor the activity log links them to the requester. Using the number
  in the id (`user_01` to `account_001`) would be a shortcut the spec does not permit, so I did not implement it.
- **Unfixed: anonymized analytics profiles with no link.** Gold verifies `ANONYMIZED` for analytics records (for
  example `analytics_9406`, `analytics_901`) that the pipeline cannot connect to the requester. Those records appear
  in batch readback logs that cover several subjects (one file lists nine different emails), so the batch cannot be
  used as a subject link.
- **Unfixed: document-only identity.** Customer statement PDFs contain the requester's name and email but no
  resource identifiers. The pipeline does not turn them into findings, which likely accounts for the 42 empty-step
  INCOMPLETE cases.
- **Unfixed: `NOT_APPLICABLE` detection is keyword-based.** It is correct for the four non-deletion phrasings in the
  dataset and for C3, but a non-deletion request in a language or phrasing the keyword lists do not cover would be
  treated as a deletion. The keyword list covers English, Spanish, Portuguese, French, German, Dutch, Russian,
  Chinese, Japanese and Korean terms, but I did not verify it against every language in the 518 requests.

## 6. Limits of this evaluation

- No hidden-set accuracy is measured, and none can be measured here.
- The sample metrics were used for tuning, so they overstate expected hidden-set accuracy.
- Operations are deterministic; no model is used, so there is no model-based variance to measure.
- OCR on the 11 screenshots was run with `tesseract` and contributed 20 observations. The OCR text was not checked
  by hand, so image-derived findings are not validated.
- The pipeline needs `pdftotext` and `tesseract` for PDF and image evidence. If either is missing, the pipeline prints
  a warning and skips that evidence, which lowers recall.
