#!/usr/bin/env python3
"""Team-created evaluation cases. Each case runs the real pipeline on a derived request file
and checks an invariant that must hold regardless of the hidden canonical answers.

Usage (from the repository root):
    python3 code/evaluation/custom_cases.py
"""
import csv
import filecmp
import json
import os
import sys
import tempfile
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, "code"))
import main as pipeline  # noqa: E402

DATASET = os.path.join(ROOT, "dataset")
PHASE_RANK = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}
OP_ORDER = pipeline.FINDING_ORDER + pipeline.REMEDIATION_ORDER + pipeline.VERIFICATION_ORDER
OP_RANK = {op: i for i, op in enumerate(OP_ORDER)}


def load_sample():
    return list(csv.DictReader(open(os.path.join(DATASET, "sample_deletion_requests.csv"), encoding="utf-8")))


def write_requests(rows, path):
    fields = ["case_id", "email", "requested_at", "reported_status", "reported_at", "audit_at", "request_text"]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def run_pipeline(rows, tmpdir, name):
    req = os.path.join(tmpdir, f"{name}_req.csv")
    out = os.path.join(tmpdir, f"{name}_out.csv")
    write_requests(rows, req)
    pipeline.run(req, out)
    return {r["case_id"]: r for r in csv.DictReader(open(out, encoding="utf-8"))}


def case_historical_email(tmpdir):
    """A request made with a historical email must resolve to the same user and give the same answer."""
    base_rows = load_sample()
    directory = pipeline.Directory()
    audit = list(csv.DictReader(open(os.path.join(DATASET, "user_audit_log.csv"), encoding="utf-8")))
    base = run_pipeline(base_rows, tmpdir, "hist_base")
    swapped, checked, mismatches = [], 0, []
    for r in base_rows:
        uid, _keys = directory.resolve(r["email"])
        hist = [a["old_value"] for a in audit if a["user_id"] == uid and a["field_name"] == "email"
                and a["old_value"] and a["old_value"].lower() != r["email"].lower()]
        if uid and hist:
            new = dict(r)
            new["email"] = hist[0]
            swapped.append(new)
            checked += 1
        else:
            swapped.append(dict(r))
    alt = run_pipeline(swapped, tmpdir, "hist_alt")
    for r in swapped:
        if r["email"] != next(x["email"] for x in base_rows if x["case_id"] == r["case_id"]):
            if (alt[r["case_id"]]["deletion_status"], alt[r["case_id"]]["steps_json"]) != (
                    base[r["case_id"]]["deletion_status"], base[r["case_id"]]["steps_json"]):
                mismatches.append(r["case_id"])
    passed = checked > 0 and not mismatches
    return passed, f"{checked} cases re-submitted with a historical email; {len(mismatches)} changed answer"


def case_no_future_evidence(tmpdir):
    """With audit_at before all evidence, no evidence may be cited and COMPLETE must not be claimed."""
    rows = load_sample()
    for r in rows:
        r["audit_at"] = "2020-01-01T00:00:00Z"
    out = run_pipeline(rows, tmpdir, "early")
    cited = sum(1 for r in out.values() for s in json.loads(r["steps_json"]) if s["evidence_id"])
    complete = [cid for cid, r in out.items() if r["deletion_status"] == "COMPLETE"]
    passed = cited == 0 and not complete
    return passed, f"cited evidence steps={cited}, COMPLETE claims={len(complete)}"


def case_non_deletion(tmpdir):
    """Requests that do not ask for deletion must be NOT_APPLICABLE with an empty step array."""
    texts = [
        "Please send me a copy of my data in a portable format.",
        "I need a copy of last year's invoices for my records. Please keep my profile.",
        "Please change the email address used for this account. I want to continue using the service.",
    ]
    rows = [dict(load_sample()[i], request_text=t) for i, t in enumerate(texts)]
    out = run_pipeline(rows, tmpdir, "nondel")
    ok = all(r["deletion_status"] == "NOT_APPLICABLE" and r["steps_json"] == "[]" for r in out.values())
    return ok, f"{len(out)} non-deletion requests -> " + ", ".join(sorted({r['deletion_status'] for r in out.values()}))


def case_output_contract(tmpdir):
    """Structural contract over the full generated output.csv (every row, every step)."""
    path = os.path.join(ROOT, "output.csv")
    if not os.path.exists(path):
        return False, "output.csv missing; run code/main.py first"
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    problems = []
    ids = [r["case_id"] for r in rows]
    if ids != sorted(ids) or len(set(ids)) != len(ids):
        problems.append("case order or duplicates")
    for r in rows:
        if r["deletion_status"] not in ("COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"):
            problems.append(f"{r['case_id']} status")
        steps = json.loads(r["steps_json"])
        if [s["step_no"] for s in steps] != list(range(1, len(steps) + 1)):
            problems.append(f"{r['case_id']} step numbering")
        keys = [(PHASE_RANK[s["phase"]], OP_RANK[s["operation"]], s["system_id"], s["resource_id"]) for s in steps]
        if keys != sorted(keys):
            problems.append(f"{r['case_id']} ordering")
        for s in steps:
            if OP_STATE_OK(s) is False:
                problems.append(f"{r['case_id']} op/state {s['operation']}/{s['state']}")
            if r["deletion_status"] == "COMPLETE" and s["phase"] != "VERIFICATION":
                problems.append(f"{r['case_id']} non-verification step in COMPLETE")
            if r["deletion_status"] == "COMPLETE" and not s["evidence_id"]:
                problems.append(f"{r['case_id']} COMPLETE step without evidence")
            if r["deletion_status"] == "INCOMPLETE" and s["phase"] != "FINDING" and s["evidence_id"]:
                problems.append(f"{r['case_id']} INCOMPLETE remediation/verification cites evidence")
        if r["deletion_status"] == "NOT_APPLICABLE" and steps:
            problems.append(f"{r['case_id']} NOT_APPLICABLE with steps")
    return not problems, f"{len(rows)} rows checked; {len(problems)} violations" + (f": {problems[:3]}" if problems else "")


def OP_STATE_OK(step):
    return pipeline.OP_STATE.get(step["operation"]) == step["state"] and pipeline.PHASE_OF.get(step["operation"]) == step["phase"]


def case_determinism(tmpdir):
    """Two independent runs over the same input produce byte-identical output."""
    rows = load_sample()
    req = os.path.join(tmpdir, "det_req.csv")
    write_requests(rows, req)
    a, b = os.path.join(tmpdir, "det_a.csv"), os.path.join(tmpdir, "det_b.csv")
    pipeline.run(req, a)
    pipeline.run(req, b)
    same = filecmp.cmp(a, b, shallow=False)
    return same, "byte-identical across two runs" if same else "outputs differ"


def main():
    cases = [
        ("C1 historical-email identity", case_historical_email),
        ("C2 no evidence after audit cutoff", case_no_future_evidence),
        ("C3 non-deletion requests", case_non_deletion),
        ("C4 output contract over output.csv", case_output_contract),
        ("C5 determinism", case_determinism),
    ]
    results = []
    with tempfile.TemporaryDirectory() as tmpdir:
        for name, fn in cases:
            try:
                passed, detail = fn(tmpdir)
            except Exception as exc:  # report, never hide
                passed, detail = False, f"exception: {exc!r}"
            results.append((name, passed, detail))
    for name, passed, detail in results:
        print(f"{'PASS' if passed else 'FAIL'}  {name}: {detail}")
    print(f"\n{sum(1 for _, p, _ in results if p)}/{len(results)} custom cases passed")


if __name__ == "__main__":
    main()
