# Usage Report - Final Full-Dataset Run

This report covers the final run that produced the root-level `output.csv` (518 requests), using the code in `code/main.py`.

## Model usage

The solution makes **no model calls**. It is fully deterministic: it reads the files in `dataset/`, applies the
rules in `code/main.py`, and writes `output.csv`. It uses no network access and no API keys.

| Item | Value |
| --- | --- |
| Model providers | None |
| Model names | None |
| Model calls | 0 |
| Input tokens | 0 |
| Output tokens | 0 |
| Total tokens | 0 |
| Average tokens per request | 0 (518 requests) |
| Estimated total cost | $0.00 |
| Estimated cost per request | $0.00 |

Per-model and overall totals: there is only one configuration, which makes no model calls, so the per-model table is
empty and the overall totals above are zero.

## Compute resources (not token usage)

| Item | Value |
| --- | --- |
| Full run wall-clock time | about 21 seconds for 518 requests (measured in the execution environment) |
| External tools used | `pdftotext` (PDF text), `tesseract` (OCR on PNG screenshots) |
| Tool calls per request | 0 (no model or network tool calls) |

The timing is the only resource measurement recorded. It is not a cost estimate.

## Notes

- Evidence is read from the `dataset/` folder; no files outside it are used for predictions.
- If a future version adds a model (for example, for ambiguous evidence), this report must be updated with the
  provider, model name, call count, token counts and cost from that run. None of those values are invented here.
