#!/usr/bin/env python3
"""Ghost Data Still Exists - deterministic deletion-audit pipeline.

Usage (from the repository root):
    python3 code/main.py                                   # full run -> ./output.csv
    python3 code/main.py --requests dataset/sample_deletion_requests.csv --out /tmp/pred.csv

Pipeline (no network, no model calls; reads only dataset/):
  1. Deletion intent: multilingual keyword check on request_text.
  2. Identity: request email (current or historical) -> user_id; identifier set from
     current + historical emails, phones and SHA-256 email hashes.
  3. Evidence: parse every JSON / TXT / LOG / SQL / PDF / image file into observations
     (resource_id, record type, state, identifiers, capture time).
  4. Subject resources: resources linked to the subject (directly, or through an account
     reference inside a linked record) at or before audit_at.
  5. Per resource: state = latest observation at or before audit_at; rule table maps
     (record type, state) to findings, remediation and verification steps.
"""
import argparse
import csv
import hashlib
import json
import os
import re
import sqlite3
import subprocess
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATASET = os.path.join(ROOT, "dataset")

# --- identifiers ------------------------------------------------------------

RESOURCE_RE = re.compile(
    r"\b(?:audit_record|data_flow|tombstone|account|search|analytics|support|export|backup)_\d+\b"
)
ACCOUNT_REF_RE = re.compile(r"\baccount_\d+\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-']+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
USER_RE = re.compile(r"\buser_\d+\b")
HEX64_RE = re.compile(r"^[0-9a-fA-F]{64}$")

PREFIX_SYSTEM = [
    ("audit_record_", "security_service"),
    ("data_flow_", "integration_service"),
    ("account_", "account_service"),
    ("search_", "search_service"),
    ("analytics_", "analytics_platform"),
    ("support_", "support_platform"),
    ("export_", "export_service"),
    ("backup_", "backup_service"),
    ("tombstone_", "identity_service"),
]
PREFIX_RTYPE = {
    "audit_record_": "SECURITY_AUDIT_LOG",
    "data_flow_": "DATA_FLOW",
    "account_": "USER_PROFILE",
    "search_": "SEARCH_INDEX_ENTRY",
    "analytics_": "ANALYTICS_PROFILE",
    "support_": "SUPPORT_MESSAGE",
    "export_": "USER_EXPORT",
    "backup_": "BACKUP_ARCHIVE",
    "tombstone_": "ACCOUNT_TOMBSTONE",
}
# Collection / table / service-export names -> record type (evidence vocabulary).
COLLECTION_RTYPE = {
    "customer_profiles": "USER_PROFILE", "customer_profiles_primary": "USER_PROFILE",
    "customer_profiles_failover_replica": "USER_PROFILE", "profile_lookups": "USER_PROFILE",
    "customer_search_documents": "SEARCH_INDEX_ENTRY", "search_documents_primary": "SEARCH_INDEX_ENTRY",
    "index_queries": "SEARCH_INDEX_ENTRY",
    "customer_analytics_reports": "ANALYTICS_PROFILE", "customer_analytics_profiles": "ANALYTICS_PROFILE",
    "profiles": "ANALYTICS_PROFILE",
    "support_conversations": "SUPPORT_MESSAGE", "support_records": "SUPPORT_MESSAGE",
    "tickets": "SUPPORT_MESSAGE", "ticket_attachments": "SUPPORT_ATTACHMENT",
    "customer_export_jobs": "USER_EXPORT", "exports": "USER_EXPORT", "customer_exports": "USER_EXPORT",
    "connector_configurations": "DATA_FLOW", "connectors": "DATA_FLOW",
    "connector_subscriptions": "DATA_FLOW",
    "backup_catalog": "BACKUP_ARCHIVE", "restore_entries": "BACKUP_ARCHIVE",
    "backup_restore_entries": "BACKUP_ARCHIVE",
    "security_audit_events": "SECURITY_AUDIT_LOG", "audit_records": "SECURITY_AUDIT_LOG",
    "security_audit_records": "SECURITY_AUDIT_LOG",
    "retained_order_records": "LEGAL_HOLD_RECORD",
    "deleted_customer_references": "ACCOUNT_TOMBSTONE",
}
# Sources whose "system" is a generic store, not the owner of the record.
GENERIC_STORES = {"backup_restore_service", "support_storage_service", "privacy_treatment_service"}

# --- states -----------------------------------------------------------------

STATE_RESULTS = {
    "FOUND": "FOUND", "HIT": "FOUND", "SUCCESS": "FOUND", "PRESENT": "FOUND",
    "NOT_FOUND": "NOT_FOUND", "ABSENT": "NOT_FOUND", "MISSING": "NOT_FOUND", "MISS": "NOT_FOUND",
    "IDENTIFIABLE": "IDENTIFIABLE", "ANONYMIZED": "ANONYMIZED", "REDACTED": "REDACTED",
    "ACTIVE": "ACTIVE", "DISABLED": "DISABLED", "BLOCKED": "BLOCKED",
}

FINDING_ORDER = ["REPORT_REMAINING_RECORD", "REPORT_EXPOSED_PII",
                 "REPORT_ACTIVE_DATA_FLOW", "REPORT_RESTORE_RISK"]
REMEDIATION_ORDER = ["DISABLE_DATA_FLOW", "BLOCK_RESTORE", "DELETE_RECORD",
                     "REDACT_RECORD", "ANONYMIZE_RECORD"]
VERIFICATION_ORDER = ["VERIFY_RECORD_ABSENT", "VERIFY_RECORD_PRESENT",
                      "VERIFY_RECORD_REDACTED", "VERIFY_RECORD_ANONYMIZED",
                      "VERIFY_DATA_FLOW_DISABLED", "VERIFY_RESTORE_BLOCKED"]
OP_STATE = {
    "REPORT_REMAINING_RECORD": "PRESENT", "REPORT_EXPOSED_PII": "PRESENT",
    "REPORT_ACTIVE_DATA_FLOW": "ACTIVE", "REPORT_RESTORE_RISK": "ACTIVE",
    "DISABLE_DATA_FLOW": "DISABLED", "BLOCK_RESTORE": "BLOCKED", "DELETE_RECORD": "ABSENT",
    "REDACT_RECORD": "REDACTED", "ANONYMIZE_RECORD": "ANONYMIZED",
    "VERIFY_RECORD_ABSENT": "ABSENT", "VERIFY_RECORD_PRESENT": "PRESENT",
    "VERIFY_RECORD_REDACTED": "REDACTED", "VERIFY_RECORD_ANONYMIZED": "ANONYMIZED",
    "VERIFY_DATA_FLOW_DISABLED": "DISABLED", "VERIFY_RESTORE_BLOCKED": "BLOCKED",
}
PHASE_OF = {}
for _ops, _ph in ((FINDING_ORDER, "FINDING"), (REMEDIATION_ORDER, "REMEDIATION"),
                  (VERIFICATION_ORDER, "VERIFICATION")):
    for _op in _ops:
        PHASE_OF[_op] = _ph
OP_RANK = {op: i for i, op in enumerate(FINDING_ORDER + REMEDIATION_ORDER + VERIFICATION_ORDER)}
PHASE_RANK = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}

DELETION_TERMS = [
    "delet", "erase", "erasure", "remov", "close my account", "closing my account",
    "close the account", "close this account", "permanent", "purge", "wipe",
    "terminate", "shut down", "cancel my account", "forget me",
    "elimin", "excluir", "borrar", "suprim", "supprim", "suppression", "effacer", "exclus",
    "lösch", "loesch", "cancell", "verwijder", "удал",
    "删除", "注销", "削除", "退会", "삭제", "탈퇴",
]


# --- generic helpers --------------------------------------------------------

def parse_ts(value):
    if not value or not isinstance(value, str):
        return None
    try:
        dt = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def sha256_email(email):
    return hashlib.sha256(email.strip().lower().encode("utf-8")).hexdigest()


def system_of_prefix(rid):
    for prefix, system in PREFIX_SYSTEM:
        if rid.startswith(prefix):
            return system
    return None


def norm_phone(p):
    digits = re.sub(r"\D", "", p or "")
    return digits if len(digits) >= 7 else None


def is_null(v):
    return v is None or (isinstance(v, str) and v.strip().lower() in ("", "null", "none", "n/a"))


def truthy(v):
    return str(v).strip().lower() in ("true", "1", "yes")


def falsy(v):
    return str(v).strip().lower() in ("false", "0", "no")


def flatten_pairs(obj, out=None):
    if out is None:
        out = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                flatten_pairs(v, out)
            elif isinstance(v, str):
                out.append((k, v))
    elif isinstance(obj, list):
        for v in obj:
            if isinstance(v, (dict, list)):
                flatten_pairs(v, out)
            elif isinstance(v, str):
                out.append(("", v))
    return out


FREE_TEXT_KEYS = {"message_text", "message_excerpt", "query", "details", "description"}


def identifier_keys(pairs):
    keys = set()
    for k, v in pairs:
        if not isinstance(v, str) or is_null(v):
            continue
        kl = (k or "").lower()
        if kl in FREE_TEXT_KEYS:
            continue
        for em in EMAIL_RE.findall(v):
            keys.add("e:" + em.lower())
        for uid in USER_RE.findall(v):
            keys.add("u:" + uid)
        if HEX64_RE.match(v.strip()):
            keys.add("h:" + v.strip().lower())
        if "phone" in kl:
            ph = norm_phone(v)
            if ph:
                keys.add("p:" + ph)
    return keys


DIRECT_ID_FIELDS = ("email", "phone", "name", "full_name", "display_name", "requester_name",
                    "requester_email", "requester_phone", "owner_email", "owner_phone",
                    "customer_email", "email_hash", "uploaded_by")


def contact_in_text(fields):
    """True if any string value carries an email address or phone number (free text included)."""
    for k, v in fields.items():
        if isinstance(v, str) and not is_null(v):
            if EMAIL_RE.search(v) or (k != "resource_id" and "phone" in k and norm_phone(v)):
                return True
    return False


def has_direct_identifier(fields):
    for k in DIRECT_ID_FIELDS:
        v = fields.get(k)
        if isinstance(v, str) and not is_null(v):
            return True
    return False


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


# --- identity ---------------------------------------------------------------

class Directory:
    def __init__(self):
        identities = read_csv(os.path.join(DATASET, "user_identities.csv"))
        audit = read_csv(os.path.join(DATASET, "user_audit_log.csv"))
        self.users = {}
        self.email_index = {}
        self.hash_index = {}

        def ensure(uid):
            if uid not in self.users:
                self.users[uid] = {"current_email": "", "emails": set(), "phones": set(), "hashes": set()}
            return self.users[uid]

        for r in identities:
            info = ensure(r["user_id"].strip())
            em = (r.get("email") or "").strip().lower()
            if em:
                info["current_email"] = em
                info["emails"].add(em)
            ph = norm_phone(r.get("phone"))
            if ph:
                info["phones"].add(ph)
            if r.get("email_hash"):
                info["hashes"].add(r["email_hash"].strip().lower())

        for r in audit:
            info = ensure(r["user_id"].strip())
            field = (r.get("field_name") or "").strip().lower()
            for val in (r.get("old_value"), r.get("new_value")):
                if not val or not val.strip():
                    continue
                if field == "email":
                    info["emails"].add(val.strip().lower())
                elif field == "phone":
                    ph = norm_phone(val)
                    if ph:
                        info["phones"].add(ph)

        for uid, info in self.users.items():
            for em in info["emails"]:
                info["hashes"].add(sha256_email(em))
                self.email_index.setdefault(em, set()).add(uid)
            for h in info["hashes"]:
                self.hash_index.setdefault(h, set()).add(uid)

    def resolve(self, request_email):
        em = (request_email or "").strip().lower()
        cands = set(self.email_index.get(em, set()))
        if em:
            cands |= self.hash_index.get(sha256_email(em), set())
        chosen = None
        if len(cands) == 1:
            chosen = next(iter(cands))
        elif cands:
            current = sorted(u for u in cands if self.users[u]["current_email"] == em)
            chosen = (current or sorted(cands))[0]
        emails, phones, hashes = ({em} if em else set()), set(), set()
        if chosen:
            info = self.users[chosen]
            emails |= info["emails"]
            phones, hashes = info["phones"], info["hashes"]
        keys = set()
        for e in emails:
            keys.add("e:" + e)
            keys.add("h:" + sha256_email(e))
        keys |= {"h:" + h for h in hashes} | {"p:" + p for p in phones}
        if chosen:
            keys.add("u:" + chosen)
        return chosen, keys


# --- observations -----------------------------------------------------------

class Obs:
    __slots__ = ("file_id", "captured", "resource_id", "system", "rtype", "state", "fields", "keys", "refs")

    def __init__(self, file_id, captured, resource_id, system, rtype, state, fields, keys, refs):
        self.file_id = file_id
        self.captured = captured
        self.resource_id = resource_id
        self.system = system
        self.rtype = rtype
        self.state = state
        self.fields = fields
        self.keys = keys
        self.refs = refs   # account resource ids referenced inside this record


def derive_state(rtype, fields, keys, explicit):
    """Map a record to one of the evidence states, preferring explicit result vocabulary."""
    if explicit and explicit.upper() in STATE_RESULTS:
        return STATE_RESULTS[explicit.upper()]
    if rtype == "DATA_FLOW":
        for k in ("enabled",):
            if k in fields and not is_null(fields[k]):
                return "ACTIVE" if truthy(fields[k]) else "DISABLED"
        return "ACTIVE"
    if rtype == "BACKUP_ARCHIVE":
        if "restore_allowed" in fields and not is_null(fields["restore_allowed"]):
            return "ACTIVE" if truthy(fields["restore_allowed"]) else "BLOCKED"
        return "ACTIVE"
    if rtype in ("ANALYTICS_PROFILE", "SUPPORT_MESSAGE", "ACCOUNT_TOMBSTONE"):
        if has_direct_identifier(fields) or contact_in_text(fields):
            return "IDENTIFIABLE"
        return "ANONYMIZED" if rtype == "ANALYTICS_PROFILE" else "REDACTED"
    status = str(fields.get("status_code", fields.get("http_status", "")) or "")
    if status == "404" or str(fields.get("rows", "")) == "0":
        return "NOT_FOUND"
    return "FOUND"


def make_obs(file_id, captured, rec, default_rtype=None, system_hint=None, rid=None):
    rid = rid or rec.get("resource_id")
    if not isinstance(rid, str) or not rid.strip():
        return None
    rid = rid.strip()
    fields = {k.lower(): v for k, v in rec.items() if not isinstance(v, (dict, list))}
    explicit_type = rec.get("record_type")
    rtype = (explicit_type if isinstance(explicit_type, str) and explicit_type.strip()
             else default_rtype)
    if not rtype:
        for prefix, t in PREFIX_RTYPE.items():
            if rid.startswith(prefix):
                rtype = t
                break
    if rtype == "SUPPORT_MESSAGE" and any(k in fields for k in ("file_name", "storage_class", "object_key")):
        rtype = "SUPPORT_ATTACHMENT"
    if "email_opt_in" in fields:
        rtype = "MARKETING_PROFILE"
    system = rec.get("system") or rec.get("origin_system")
    if not system or system in GENERIC_STORES and system_hint:
        system = system_hint or system
    if not system:
        system = system_of_prefix(rid)
    pairs = flatten_pairs(rec)
    keys = identifier_keys(pairs)
    refs = set(ACCOUNT_REF_RE.findall(" ".join(v for _, v in pairs if isinstance(v, str))))
    refs.discard(rid)
    explicit = fields.get("result") if isinstance(fields.get("result"), str) else None
    state = derive_state(rtype, fields, keys, explicit)
    return Obs(file_id, captured, rid, system, rtype, state, fields, keys, refs)


def parse_json(file_id, path, cap_default):
    out = []
    data = json.load(open(path, encoding="utf-8"))

    def add(rec, cap, rtype=None, system=None):
        o = make_obs(file_id, cap, rec, rtype, system)
        if o is not None:
            out.append(o)

    if isinstance(data, dict) and "snapshots" in data:
        for snap in data.get("snapshots") or []:
            cap = parse_ts(snap.get("captured_at")) or cap_default
            coll = snap.get("collection")
            rtype = COLLECTION_RTYPE.get(coll)
            for rec in snap.get("records") or []:
                if isinstance(rec, dict):
                    add(rec, parse_ts(rec.get("recorded_at")) or cap, rtype, snap.get("data_store"))
    elif isinstance(data, dict) and "service_exports" in data:
        top = parse_ts(data.get("exported_at")) or cap_default
        for svc, sections in (data.get("service_exports") or {}).items():
            if not isinstance(sections, dict):
                continue
            for section, items in sections.items():
                rtype = COLLECTION_RTYPE.get(section)
                for item in items or []:
                    if not isinstance(item, dict):
                        continue
                    if "profile" in item:
                        flat = {k: v for k, v in item.items() if k != "profile"}
                        prof = item.get("profile")
                        if isinstance(prof, dict):
                            flat.update(prof)
                        flat["status_code"] = item.get("status_code")
                        if prof is None:
                            flat["result"] = "NOT_FOUND"
                        add(flat, parse_ts(item.get("observed_at")) or top, rtype or "USER_PROFILE", svc)
                    elif "hits" in item:
                        docs = (item.get("hits") or {}).get("documents") or []
                        for d in docs:
                            if isinstance(d, dict) and d.get("resource_id"):
                                add(d, parse_ts(item.get("observed_at")) or top, rtype or "SEARCH_INDEX_ENTRY", svc)
                        if not docs and item.get("resource_id"):
                            add({"resource_id": item["resource_id"], "result": "NOT_FOUND"},
                                parse_ts(item.get("observed_at")) or top, rtype, svc)
                    else:
                        add(item, parse_ts(item.get("observed_at")) or top, rtype, svc)
    elif isinstance(data, dict) and "records" in data:
        default_cap = parse_ts(data.get("captured_at") or data.get("exported_at")) or cap_default
        rtype = COLLECTION_RTYPE.get(data.get("collection"))
        for rec in data.get("records") or []:
            if isinstance(rec, dict):
                add(rec, parse_ts(rec.get("recorded_at")) or default_cap, rtype, data.get("source"))
    elif isinstance(data, list):
        for rec in data:
            if isinstance(rec, dict):
                add(rec, cap_default)
    return out


def parse_handover(file_id, path, cap_default):
    out = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line.startswith("-"):
                continue
            parts = [p.strip() for p in line.lstrip("-").split("|")]
            if len(parts) < 5 or not RESOURCE_RE.fullmatch(parts[2]):
                continue
            rec = {"resource_id": parts[2], "system": parts[1], "record_type": parts[3], "result": parts[4]}
            ident = " ".join(parts[5:])
            rec["_lookup"] = ident
            o = make_obs(file_id, parse_ts(parts[0]) or cap_default, rec)
            if o is not None:
                o.keys |= identifier_keys([("", ident)])
                out.append(o)
    return out


KV_RE = re.compile(r'(\w+)=("[^"]*"|\S+)')
SERVICE_RTYPE = {
    "support_replica": "SECONDARY_IDENTIFIER",
    "account_service": "USER_PROFILE", "search_service": "SEARCH_INDEX_ENTRY",
    "search_index_service": "SEARCH_INDEX_ENTRY", "analytics_platform": "ANALYTICS_PROFILE",
    "support_platform": "SUPPORT_MESSAGE",
    "export_service": "USER_EXPORT", "backup_service": "BACKUP_ARCHIVE",
    "integration_service": "DATA_FLOW", "security_service": "SECURITY_AUDIT_LOG",
}


def parse_log(file_id, path, cap_default):
    """Log lines are observations only when they report a result (not a *_started request).
    Identifiers are shared across lines with the same trace_id, so a lookup_key on the
    request line also identifies the result line that carries only resource_id."""
    lines = []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.rstrip("\n")
            cap = parse_ts(line.split(" ", 1)[0]) or cap_default
            kv = {k.lower(): v.strip('"') for k, v in KV_RE.findall(line)}
            lines.append((cap, kv))

    trace_keys = {}
    for _cap, kv in lines:
        tid = kv.get("trace_id")
        if tid:
            trace_keys.setdefault(tid, set()).update(identifier_keys(list(kv.items())))

    out = []
    for cap, kv in lines:
        rid = kv.get("resource_id")
        if not rid or is_null(rid) or not RESOURCE_RE.fullmatch(rid):
            continue
        event = kv.get("event", "")
        if "started" in event or "connection_acquired" in event or "cache_lookup" in event:
            continue
        rec = {k: (None if is_null(v) else v) for k, v in kv.items()}
        rec["resource_id"] = rid
        rtype = SERVICE_RTYPE.get(kv.get("service", ""))
        if rec.get("rows") == "0" or rec.get("http_status") == "404":
            rec["result"] = "NOT_FOUND"
        elif rec.get("result", "").lower() == "hit":
            rec["result"] = "FOUND"
        o = make_obs(file_id, cap, rec, rtype, None, rid)
        if o is not None:
            o.keys = identifier_keys(list(kv.items())) | trace_keys.get(kv.get("trace_id", ""), set())
            out.append(o)
    return out


def parse_sql(file_id, path, cap_default):
    out = []
    con = sqlite3.connect(":memory:")
    try:
        con.executescript(open(path, encoding="utf-8").read())
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        for table in tables:
            if table == "snapshot_scope":
                continue
            cur = con.execute(f'SELECT * FROM "{table}"')
            cols = [d[0] for d in cur.description]
            for row in cur.fetchall():
                rec = dict(zip(cols, row))
                if "record_json" in rec and rec["record_json"]:
                    try:
                        inner = json.loads(rec["record_json"])
                    except json.JSONDecodeError:
                        inner = {}
                    inner.setdefault("resource_id", rec.get("resource_id"))
                    rtype = COLLECTION_RTYPE.get(rec.get("collection_name"))
                    o = make_obs(file_id, cap_default, inner, rtype, rec.get("origin_system"))
                else:
                    rtype = COLLECTION_RTYPE.get(table) or _table_hint(table)
                    o = make_obs(file_id, cap_default, rec, rtype,
                                 table_system(table, rec.get("origin_system")))
                if o is not None:
                    out.append(o)
    finally:
        con.close()
    return out


def _table_hint(table):
    if table.startswith("customer_profiles"):
        return "USER_PROFILE"
    return None


def table_system(table, origin):
    if origin:
        return origin
    if table.startswith("customer_profiles"):
        return "account_service"
    return None


WARNED_TOOLS = set()


def document_text(path):
    """Text of a PDF (pdftotext) or image (tesseract OCR). Missing tools are reported, not hidden."""
    tool = "pdftotext" if path.lower().endswith(".pdf") else "tesseract"
    cmd = ["pdftotext", "-layout", path, "-"] if tool == "pdftotext" else ["tesseract", path, "-"]
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=240).stdout
    except FileNotFoundError:
        if tool not in WARNED_TOOLS:
            WARNED_TOOLS.add(tool)
            print(f"WARNING: '{tool}' not found; {tool}-based evidence will be skipped.")
        return ""
    except (OSError, subprocess.SubprocessError):
        return ""


def parse_document(file_id, path, cap_default):
    """PDF / image: each resource id mentioned is an observation of that resource."""
    text = document_text(path)
    keys = identifier_keys([("", text)])
    refs = set(ACCOUNT_REF_RE.findall(text))
    is_attachment = "attachment" in os.path.basename(path).lower() or "attachment" in text.lower()
    out = []
    for rid in sorted(set(RESOURCE_RE.findall(text))):
        rtype = None
        if rid.startswith("support_") and is_attachment:
            rtype = "SUPPORT_ATTACHMENT"
        o = make_obs(file_id, cap_default, {"resource_id": rid}, rtype, None, rid)
        if o is None:
            continue
        o.keys = set(keys)
        o.refs = refs - {rid}
        o.state = "FOUND"
        out.append(o)
    return out


def load_observations():
    manifest = {r["file_id"]: r for r in read_csv(os.path.join(DATASET, "evidence_files.csv"))}
    obs = []
    for file_id in sorted(manifest):
        path = os.path.join(DATASET, manifest[file_id]["file_path"])
        if not os.path.exists(path):
            continue
        cap = parse_ts(manifest[file_id]["captured_at"])
        ext = os.path.splitext(path)[1].lower()
        parser = {".json": parse_json, ".txt": parse_handover, ".log": parse_log,
                  ".sql": parse_sql, ".pdf": parse_document, ".png": parse_document,
                  ".jpg": parse_document, ".jpeg": parse_document}.get(ext)
        if parser is None:
            continue
        try:
            obs += parser(file_id, path, cap)
        except (OSError, ValueError, sqlite3.Error, json.JSONDecodeError):
            continue
    return obs


class Index:
    def __init__(self, observations):
        self.by_key, self.by_resource = {}, {}
        for o in observations:
            for k in o.keys:
                self.by_key.setdefault(k, []).append(o)
            self.by_resource.setdefault(o.resource_id, []).append(o)

    def latest(self, rid, audit_at):
        cands = [o for o in self.by_resource.get(rid, []) if o.captured and o.captured <= audit_at]
        return max(cands, key=lambda o: (o.captured, o.file_id)) if cands else None

    def first_with_state(self, rid, audit_at, state):
        """Earliest observation at or before audit_at that already shows `state` (the citation)."""
        cands = [o for o in self.by_resource.get(rid, [])
                 if o.captured and o.captured <= audit_at and o.state == state]
        return min(cands, key=lambda o: (o.captured, o.file_id)).file_id if cands else None


# --- deletion intent --------------------------------------------------------

# Requests to confirm that data is gone or unidentifiable also authorise a deletion audit
# (e.g. "confirm that the profile is gone"). Anything with neither kind of wording is
# not a deletion request and is reported as NOT_APPLICABLE.
VERIFY_GONE_TERMS = [
    "is gone", "are gone", "still existed", "still exists", "still recognized",
    "cannot identify me", "can no longer", "no longer identif", "still appears", "still shows",
]


def requests_deletion(text):
    t = (text or "").lower()
    return any(term in t for term in DELETION_TERMS) or any(term in t for term in VERIFY_GONE_TERMS)


# --- rules ------------------------------------------------------------------

class Step:
    __slots__ = ("phase", "operation", "system_id", "resource_id", "state", "evidence_id")

    def __init__(self, operation, system_id, resource_id, evidence_id):
        self.phase = PHASE_OF[operation]
        self.operation = operation
        self.system_id = system_id
        self.resource_id = resource_id
        self.state = OP_STATE[operation]
        self.evidence_id = evidence_id

    def sort_key(self):
        return (PHASE_RANK[self.phase], OP_RANK[self.operation], self.system_id, self.resource_id)


def handle_resource(latest, findings, remediation, verification, rid, linked, ev):
    """Apply deletion_rules.csv to one resource given its latest state at audit_at.
    `ev` is the evidence file cited for the observed state."""
    rtype, state = latest.rtype, latest.state
    system = system_of_prefix(rid) or latest.system

    if rtype == "USER_PROFILE":
        if state == "FOUND" and linked:
            findings.append(Step("REPORT_REMAINING_RECORD", system, rid, ev))
            remediation.append(Step("DELETE_RECORD", system, rid, ""))
            verification.append(Step("VERIFY_RECORD_ABSENT", system, rid, ""))
        elif state == "NOT_FOUND":
            verification.append(Step("VERIFY_RECORD_ABSENT", system, rid, ev))

    elif rtype in ("SEARCH_INDEX_ENTRY", "SUPPORT_ATTACHMENT", "USER_EXPORT"):
        if state == "FOUND" and linked:
            findings.append(Step("REPORT_REMAINING_RECORD", system, rid, ev))
            remediation.append(Step("DELETE_RECORD", system, rid, ""))
            verification.append(Step("VERIFY_RECORD_ABSENT", system, rid, ""))

    elif rtype == "SUPPORT_MESSAGE":
        if state == "IDENTIFIABLE" and linked:
            findings.append(Step("REPORT_EXPOSED_PII", system, rid, ev))
            remediation.append(Step("REDACT_RECORD", system, rid, ""))
            verification.append(Step("VERIFY_RECORD_REDACTED", system, rid, ""))
        elif state == "REDACTED":
            verification.append(Step("VERIFY_RECORD_REDACTED", system, rid, ev))

    elif rtype == "ANALYTICS_PROFILE":
        if state == "IDENTIFIABLE" and linked:
            findings.append(Step("REPORT_EXPOSED_PII", system, rid, ev))
            remediation.append(Step("ANONYMIZE_RECORD", system, rid, ""))
            verification.append(Step("VERIFY_RECORD_ANONYMIZED", system, rid, ""))
        elif state == "ANONYMIZED":
            verification.append(Step("VERIFY_RECORD_ANONYMIZED", system, rid, ev))

    elif rtype == "ACCOUNT_TOMBSTONE":
        if state == "IDENTIFIABLE" and linked:
            findings.append(Step("REPORT_EXPOSED_PII", system, rid, ev))
            remediation.append(Step("REDACT_RECORD", system, rid, ""))
            verification.append(Step("VERIFY_RECORD_REDACTED", system, rid, ""))
        elif state == "REDACTED":
            verification.append(Step("VERIFY_RECORD_REDACTED", system, rid, ev))

    elif rtype == "DATA_FLOW":
        if state == "ACTIVE" and linked:
            findings.append(Step("REPORT_ACTIVE_DATA_FLOW", system, rid, ev))
            remediation.append(Step("DISABLE_DATA_FLOW", system, rid, ""))
            verification.append(Step("VERIFY_DATA_FLOW_DISABLED", system, rid, ""))
        elif state == "DISABLED":
            verification.append(Step("VERIFY_DATA_FLOW_DISABLED", system, rid, ev))

    elif rtype == "BACKUP_ARCHIVE":
        if state == "ACTIVE" and linked:
            findings.append(Step("REPORT_RESTORE_RISK", system, rid, ev))
            remediation.append(Step("BLOCK_RESTORE", system, rid, ""))
            verification.append(Step("VERIFY_RESTORE_BLOCKED", system, rid, ""))
        elif state == "BLOCKED":
            verification.append(Step("VERIFY_RESTORE_BLOCKED", system, rid, ev))

    elif rtype in ("MARKETING_PROFILE", "SECONDARY_IDENTIFIER"):
        if state == "FOUND" and linked:
            findings.append(Step("REPORT_REMAINING_RECORD", system, rid, ev))
            remediation.append(Step("DELETE_RECORD", system, rid, ""))
            verification.append(Step("VERIFY_RECORD_ABSENT", system, rid, ""))

    elif rtype in ("SECURITY_AUDIT_LOG", "LEGAL_HOLD_RECORD"):
        if state == "FOUND" and linked:
            verification.append(Step("VERIFY_RECORD_PRESENT", system, rid, ev))


def audit_case(case, directory, index):
    if not requests_deletion(case["request_text"]):
        return "NOT_APPLICABLE", []

    audit_at = parse_ts(case["audit_at"])
    user_id, user_keys = directory.resolve(case["email"])

    # Subject resources: directly linked records at or before audit_at, plus account
    # resources referenced by those records (e.g. a search document's source account).
    linked_resources = set()
    for k in user_keys:
        for o in index.by_key.get(k, []):
            if o.captured and o.captured <= audit_at:
                linked_resources.add(o.resource_id)
                linked_resources |= {r for r in o.refs if r.startswith("account_")}
    # Account reference can also come from an observed account resource's own refs.
    subject = set(linked_resources)
    for rid in list(linked_resources):
        for o in index.by_resource.get(rid, []):
            if o.captured and o.captured <= audit_at:
                subject |= {r for r in o.refs if r.startswith("account_")}

    findings, remediation, verification = [], [], []
    for rid in sorted(subject):
        latest = index.latest(rid, audit_at)
        if latest is None:
            if rid.startswith("account_"):
                verification.append(Step("VERIFY_RECORD_ABSENT", "account_service", rid, ""))
            continue
        linked = rid in linked_resources
        ev = index.first_with_state(rid, audit_at, latest.state)
        handle_resource(latest, findings, remediation, verification, rid, linked, ev)

    status = "INCOMPLETE" if findings else "COMPLETE"
    if status == "COMPLETE":
        # COMPLETE must be proven: keep only cited verification steps. With no cited proof
        # the completion cannot be shown, so the case is reported as INCOMPLETE.
        remediation = []
        verification = [s for s in verification if s.evidence_id]
        if not verification:
            status = "INCOMPLETE"
    else:
        # Remediation and future verification carry no evidence id.
        for s in verification:
            s.evidence_id = ""

    ordered = []
    for group in (findings, remediation, verification):
        seen = set()
        for s in sorted(group, key=Step.sort_key):
            key = (s.operation, s.system_id, s.resource_id)
            if key not in seen:
                seen.add(key)
                ordered.append(s)

    steps = [{"step_no": i, "phase": s.phase, "system_id": s.system_id, "resource_id": s.resource_id,
              "operation": s.operation, "state": s.state, "evidence_id": s.evidence_id}
             for i, s in enumerate(ordered, start=1)]
    return status, steps


def run(requests_path, out_path):
    directory = Directory()
    index = Index(load_observations())
    cases = read_csv(requests_path)
    rows = sorted(((c["case_id"],) + audit_case(c, directory, index) for c in cases), key=lambda r: r[0])
    with open(out_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["case_id", "deletion_status", "steps_json"])
        for cid, status, steps in rows:
            w.writerow([cid, status, json.dumps(steps, ensure_ascii=False, separators=(",", ":"))])
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--requests", default=os.path.join(DATASET, "deletion_requests.csv"))
    ap.add_argument("--out", default=os.path.join(ROOT, "output.csv"))
    args = ap.parse_args()
    rows = run(args.requests, args.out)
    print(f"wrote {len(rows)} rows to {args.out}")


if __name__ == "__main__":
    main()
