# Ghost Data Still Exists - deletion audit pipeline

Deterministic audit of deletion requests. No model calls, no network, standard library only.
External tools: `pdftotext` (poppler-utils) for PDFs and `tesseract` for PNG screenshots. Without them the
pipeline prints a warning and skips that evidence.

## Run (from the repository root, next to dataset/)

    python3 code/main.py                       # writes output.csv (518 rows)
    python3 code/evaluation/main.py --pred output.csv --gold dataset/sample_output.csv   # needs a sample run
    python3 code/main.py --requests dataset/sample_deletion_requests.csv --out /tmp/s.csv
    python3 code/evaluation/main.py --pred /tmp/s.csv --gold dataset/sample_output.csv
    python3 code/evaluation/custom_cases.py    # five team-created checks

Python 3.9+. Reads only dataset/. Writes only the output path given.

## Approach

1. Deletion intent from request_text (multilingual keywords); non-deletion requests are NOT_APPLICABLE.
2. Identity: request email (current or historical) -> user_id; identifiers from emails, phones, SHA-256 hashes.
3. Evidence: JSON, TXT handover, logs (linked by trace_id), SQLite dumps (record_json expanded), PDFs and OCR.
4. Subject resources: linked records plus account references inside them.
5. State at audit_at from explicit result vocabulary; citation = earliest observation showing that state.
6. Rules map record type and state to findings, remediation and verification in the specified order.
7. COMPLETE only with cited verification; otherwise INCOMPLETE.

## Known limits

See code/evaluation/evaluation_report.md: sample scores are development-set results; 42 INCOMPLETE cases have
no steps because their identity appears only in a document; some accounts and anonymized analytics records
cannot be linked to the subject from the evidence.
